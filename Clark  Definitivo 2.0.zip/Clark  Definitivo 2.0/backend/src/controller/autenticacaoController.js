import { Router } from "express";
import bcrypt from "bcrypt";

import { sendMail } from "../utils/mailservice.js";
import { generateToken, getTokenInfo } from "../utils/jwt.js";

import * as repo from "../repository/usuarioRepository.js";

const endpoints = Router();

endpoints.post("/esqueceu-senha", async (req, resp) => {
  try {
    const { email } = req.body;
    const usuario = await repo.buscarPorEmail(email);

    if (!usuario)
      return resp.json({ message: "Se o e-mail existir, o link foi enviado." });

    const token = generateToken({
      id_user: usuario.id_user,
      role: usuario.tipo_perfil,
    });

    const link = `https://seusite.com/reset-password?token=${token}`;

    await sendMail(
      email,
      "Recuperação de senha",
      `Olá ${usuario.nome},\n\nClique no link para redefinir sua senha:\n${link}\n\nEsse link expira em 1 hora.`
    );

    resp.json({ message: "Se o e-mail existir, o link foi enviado." });
  } catch (err) {
    console.error(err);
    resp.status(500).json({ error: "Erro ao solicitar recuperação de senha." });
  }
});

endpoints.post("/reset-senha", async (req, resp) => {
  try {
    const { token, novaSenha } = req.body;

    const payload = getTokenInfo({ headers: { "x-access-token": token } });

    if (!payload)
      return resp.status(400).json({ error: "Token inválido ou expirado." });

    const hash = await bcrypt.hash(novaSenha, 10);
    await repo.atualizarSenha(payload.id_user, hash);

    resp.json({ message: "Senha redefinida com sucesso!" });
  } catch (err) {
    console.error(err);
    resp.status(500).json({ error: "Erro ao redefinir senha." });
  }
});

export default endpoints;
