import { Router } from "express";
import { getAuthentication } from "../utils/jwt.js";
import * as chatRepo from "../repository/chatRepository.js";
import * as salaRepo from "../repository/salaRepository.js";

const endpoints = Router();
const autenticador = getAuthentication();

// Criar sala entre dois
endpoints.post("/sala", autenticador, async (req, resp) => {
  try {
    const usuario1 = req.user.id_user;
    const { outroUsuarioId } = req.body;

    const nomeSala = `chat_${usuario1}_${outroUsuarioId}`;

    const sala = await salaRepo.criarSala(usuario1, outroUsuarioId, nomeSala);

    resp.send({
      id: sala.id,
      nome: sala.nome_sala,
    });
  } catch (err) {
    console.error("Erro ao criar sala:", err);
    resp.status(500).send({ erro: "Erro ao criar sala" });
  }
});

// Enviar mensagem
endpoints.post("/chat/:sala", autenticador, async (req, resp) => {
  try {
    const salaId = req.params.sala;
    const { usuarioId, mensagem } = req.body;

    const id = await chatRepo.inserirMensagem(usuarioId, salaId, mensagem);
    resp.send({ NovoID: id });
  } catch (err) {
    console.error("Erro ao enviar mensagem:", err);
    resp.status(500).send({ erro: "Erro ao enviar mensagem" });
  }
});

// Listar mensagens de uma sala
endpoints.get("/chat/:sala", autenticador, async (req, resp) => {
  try {
    const salaId = req.params.sala;
    const mensagens = await chatRepo.listarMensagensPorSala(salaId);
    resp.send(mensagens);
  } catch (err) {
    console.error("Erro ao listar mensagens:", err);
    resp.status(500).send({ erro: "Erro ao listar mensagens" });
  }
});

// Listar salas
endpoints.get("/salas", autenticador, async (req, resp) => {
  try {
    const usuarioId = req.user.id_user;
    const salas = await salaRepo.listarSalasDoUsuario(usuarioId);
    resp.send(salas);
  } catch (err) {
    console.error("Erro ao listar salas:", err);
    resp.status(500).send({ erro: "Erro ao listar salas" });
  }
});

export default endpoints;
