import { Router } from 'express';
import multer from 'multer';
import * as repo from '../repository/intermediarRepository.js';

const upload = multer({ dest: 'public/storage' });
const endpoints = Router();

endpoints.post('/form/intermediador', async (req, resp) => {
    try {
        const novoInter = req.body;

        
        const idInter = await repo.inserirIntermediador(novoInter);

        await repo.criarUsuarioIntermediador(
            idInter,
            novoInter.nome_inter,
            novoInter.email_inter,
            novoInter.senha_inter
        );

        resp.send({ novoID: idInter });
    } catch (error) {
        console.error('Erro ao inserir intermediador:', error);
        resp.status(500).send({ erro: 'Erro ao cadastrar intermediador.' });
    }
});

endpoints.put('/form-inter/atualizar/:id', async (req, resp) => {
    try {
        const id = Number(req.params.id);
        const novosDados = req.body;
        await repo.atualizarPerfil(novosDados, id);

        resp.send({ mensagem: 'Perfil atualizado com sucesso.' });
    } 
    
    catch (error) {
        console.error('Erro ao atualizar perfil:', error);
        resp.status(500).send({ erro: 'Erro ao atualizar perfil.' });
    }
});

endpoints.put('/perfil/:id/imagem', upload.single('img'), async (req, resp) => {
    try {

        const caminho = req.file.path;
        const id = req.params.id;

        await repo.alterarImagem(id, caminho);
        resp.send({ mensagem: 'Imagem atualizada com sucesso.' });

    } 
    
    catch (error) {
        
        console.error('Erro ao alterar imagem:', error);
        resp.status(500).send({ erro: 'Erro ao alterar imagem.' });
    }
});

export default endpoints;
