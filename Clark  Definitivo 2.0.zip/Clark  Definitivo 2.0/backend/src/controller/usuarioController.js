import * as repo from "../repository/usuarioRepository.js";
import { generateToken } from "../utils/jwt.js";

import { Router } from "express";

import { getAuthentication } from "../utils/jwt.js";
import multer from "multer";

const upload = multer({ dest: "public/storage" });
const endpoints = Router();
const autenticador = getAuthentication();

// Criar usuário
endpoints.post("/usuario", async (req, resp) => {
  let novoLogin = req.body;
  let id = await repo.criarConta(novoLogin);

  resp.send({ novoId: id });
});

endpoints.post("/usuario/login", async (req, resp) => {
  let email = req.body.email;
  let senha = req.body.senha;

  let credenciais = await repo.validarCredenciais(email, senha);
  if (!credenciais) {
    return resp.status(401).send({ erro: "Credenciais inválidas" });
  }

  let token = generateToken(credenciais);
  resp.send({ token: token });
});

endpoints.post("/usuario/criar-adm", async (req, resp) => {
  try {
    const { nome, email, senha } = req.body;

    const tipo_perfil = "adm";

    const novoAdm = {
      nome,
      email,
      senha,
      tipo_perfil,
    };

    const id = await repo.criarConta(novoAdm);

    const usuarioCriado = await repo.buscarPorId(id);
    const token = generateToken(usuarioCriado);

    resp.status(201).send({ token });
  } catch (error) {
    console.error("Erro ao criar administrador:", error);
    resp.status(500).send({ erro: "Erro ao criar administrador." });
  }
});

endpoints.get("/usuario/:id", autenticador, async (req, resp) => {
  let id = Number(req.params.id);
  let usuario = await repo.buscarPorId(id);

  if (!usuario) {
    resp.status(404).send({ error: "Usuário não encontrado." });
  } else {
    resp.send(usuario);
  }
});

endpoints.get(
  "/usuario/perfil-completo/:id",
  autenticador,
  async (req, resp) => {
    try {
      let id = Number(req.params.id);
      let perfilCompleto = await repo.buscarPerfilCompleto(id);

      if (!perfilCompleto) {
        resp.status(404).send({ error: "Perfil não encontrado." });
      } else {
        resp.send(perfilCompleto);
      }
    } catch (error) {
      console.error("Erro ao buscar perfil completo:", error);
      resp.status(500).send({ error: "Erro interno do servidor" });
    }
  }
);

endpoints.put("/usuario/perfil/:id", autenticador, async (req, resp) => {
  try {
    let id = Number(req.params.id);
    let novosDados = req.body;

    await repo.atualizarPerfil(novosDados, id);
    resp.send({ message: "Perfil atualizado com sucesso!" });
  } catch (error) {
    console.error("Erro ao atualizar perfil:", error);
    resp.status(500).send({ error: "Erro ao atualizar perfil" });
  }
});

// Upload de imagem de perfil
endpoints.put(
  "/usuario/:id/imagem",
  autenticador,
  upload.single("img"),
  async (req, resp) => {
    try {
      let id = Number(req.params.id);
      let caminho = req.file.path;

      await repo.atualizarImagemPerfil(id, caminho);
      resp.send({
        message: "Imagem atualizada com sucesso!",
        caminho: caminho,
      });
    } catch (error) {
      console.error("Erro ao atualizar imagem:", error);
      resp.status(500).send({ error: "Erro ao atualizar imagem" });
    }
  }
);

// Deletar usuário
endpoints.delete("/usuario/:id", autenticador, async (req, resp) => {
  let id = Number(req.params.id);
  await repo.deletarUsuario(id);

  resp.send({ message: "Usuário deletado com sucesso!" });
});

export default endpoints;
