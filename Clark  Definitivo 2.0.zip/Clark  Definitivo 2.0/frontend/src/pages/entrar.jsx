import React, { useState } from "react";
import axios from "axios";
import Cabecalho_Logar from "../components/cabecalho-logar";
import Clark from "../assets/images/Clark_2.0-semFundo.png";
import "../style/entrar.scss";
import { FaEye, FaEyeSlash } from "react-icons/fa";

export default function Entrar() {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [mostrarSenha, setMostrarSenha] = useState(false);
  const [erro, setErro] = useState("");

  const alternarVisibilidadeSenha = () => {
    setMostrarSenha(!mostrarSenha);
  };

  const handleLogin = async () => {
    if (!email || !senha) {
      setErro("Preencha todos os campos!");
      return;
    }

    try {
      const resp = await axios.post("http://localhost:5010/login", {
        email,
        senha,
      });

      localStorage.setItem("token", resp.data.token);
      localStorage.setItem("userData", JSON.stringify(resp.data.user));
      window.location.href = "/perfil";
    } catch (err) {
      console.error(err);
      if (err.response && err.response.status === 401) {
        setErro("Email ou senha incorretos!");
      } else {
        setErro("Erro ao conectar com o servidor!");
      }
    }
  };

  return (
    <div>
      <Cabecalho_Logar />
      <div className="container-entrar">
        <img src={Clark} alt="Clark" className="logo" />
        <h1>
          Ajuda você a se conectar e compartilhar com as pessoas que fazem parte
          da sua vida.
        </h1>
        <div className="container-quadrado">
          <div className="container-inputs">
            {erro && <p className="erro">{erro}</p>}
            <label>
              <input
                type="text"
                placeholder="Email ou telefone"
                className="input-login"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </label>
            <label>
              <input
                type={mostrarSenha ? "text" : "password"}
                placeholder="Senha"
                className="input-senha"
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
              />
              <span className="eye-icon" onClick={alternarVisibilidadeSenha}>
                {mostrarSenha ? <FaEyeSlash /> : <FaEye />}
              </span>
            </label>
            <button className="btn-entrar" onClick={handleLogin}>
              Entrar
            </button>
            <div className="linha"></div>
            <button className="btn-criar-conta">
              <a href="/escolha">Criar nova conta</a>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
