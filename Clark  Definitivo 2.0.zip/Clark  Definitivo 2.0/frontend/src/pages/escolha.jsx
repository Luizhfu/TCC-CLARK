import Cabecalho_inicio from "../components/cabecalho-inicio";
import "../style/escolha.scss";
import { Link } from "react-router";
export default function Escolha() {
  {
    return (
      <div>
        <Cabecalho_inicio></Cabecalho_inicio>

        <h1 className="inika-bold titulo-escolha">O QUE VOCÊ É?</h1>

        <div className="container-escolha">
          <section className="escolha">
            <div className="Cartao">
              <img
                className="img-estado"
                src="/src/assets/images/Empresa.png"
                alt="Empresa"
              />

              <h2 className="sub-titulo inika-regular">Empresa</h2>
              <img
                className="img-selo"
                src="/src/assets/images/Selo Empresa.png"
                alt=""
              />
            </div>

            <button className="btn-escolha">
              <Link to="/empresa">
                <h2>Entrar</h2>
              </Link>
            </button>
          </section>

          <section className="escolha">
            <div className="Cartao">
              <img
                className="img-estado"
                src="/src/assets/images/Mediador.png"
                alt="Mediador"
              />

              <h2 className="sub-titulo inika-regular">Mediador</h2>
              <img
                className="img-selo"
                src="/src/assets/images/Selo Mediador.png"
                alt=""
              />
            </div>

            <button className="btn-escolha">
              <Link to="/intermediador">
                <h2>Entrar</h2>
              </Link>
            </button>
          </section>

          <section className="escolha">
            <div className="Cartao">
              <img
                className="img-estado"
                src="/src/assets/images/Empregado.png"
                alt="Funcionario"
              />

              <h2 className="sub-titulo inika-regular">Trabalhador</h2>
              <img
                className="img-selo"
                src="/src/assets/images/Selo Empregado.png"
                alt=""
              />
            </div>
            <button className="btn-escolha">
              <Link to="/trabalhador">
                <h2>Entrar</h2>
              </Link>
            </button>
          </section>
        </div>
      </div>
    );
  }
}
