import { useEffect, useState } from "react";
import "../style/procura.scss";
import axios from "axios";
import OIP from "../assets/images/Clark_2.0.png";
import Cabecalho from "../components/cabecalho-perfilPadrao-chat";
import { useNavigate } from "react-router-dom";

export default function Procura() {
  const [selecionado, setSelecionado] = useState("empresa");
  const [usuarios, setUsuarios] = useState([]);
  const navigate = useNavigate();

  const token = localStorage.getItem("token");

  useEffect(() => {

    async function carregarUsuarios() {
      setUsuarios([]);
      try {
        const { data } = await axios.get(
          `http://localhost:5010/procura/${selecionado}`,
          {
            headers: { "x-access-token": token }, // deixei, pois você não pediu para remover
          }
        );
        setUsuarios(data);
      } catch (erro) {
        console.error("Erro ao buscar usuários:", erro);
      }
    }

    // 🔥 AGORA ELE ENTRA DIRETO — sem verificar token
    carregarUsuarios();

  }, [selecionado, token, navigate]);

  function pegarFoto(usuario) {
    return usuario.img_perfil
      ? `http://localhost:5010/${usuario.img_perfil}`
      : OIP;
  }

  function pegarNome(usuario) {
    return usuario.nome || "Nome não disponível";
  }

  function pegarBio(usuario) {
    return usuario.bio || "Biografia não disponível";
  }

  async function handleIniciarChat(usuarioSelecionadoId) {
    try {
      const { data } = await axios.post(
        "http://localhost:5010/sala",
        { outroUsuarioId: usuarioSelecionadoId },
        { headers: { "x-access-token": token } } // mantido
      );

      window.location.href = `/entrar?salaId=${data.id}`;
    } catch (err) {
      console.error("Erro ao criar sala:", err);
    }
  }
  return (
    <div className="container-procura">
      <Cabecalho />

      <div className="usuario-inter">
        <div className="opcoes">
          <div
            className={`opcao ${selecionado === "empresa" ? "ativo" : ""}`}
            onClick={() => setSelecionado("empresa")}
          >
            {selecionado === "empresa" && <span className="check">✔</span>}
            <p>Empresa</p>
          </div>

          <div
            className={`opcao ${selecionado === "funcionario" ? "ativo" : ""}`}
            onClick={() => setSelecionado("funcionario")}
          >
            {selecionado === "funcionario" && <span className="check">✔</span>}
            <p>Funcionário</p>
          </div>
        </div>
      </div>

      <div className="lista-usuarios">
        {usuarios.length === 0 ? (
          <p>Nenhum usuário encontrado.</p>
        ) : (
          usuarios.map((u) => (
            <div
              key={u.id}
              className="usuario-card"
              onClick={() => handleIniciarChat(u.id)}
            >
              <img
                src={pegarFoto(u)}
                alt={`Foto de ${pegarNome(u)}`}
                className="foto-usuario"
              />
              <h3>{pegarNome(u)}</h3>
              <p className="bio">{pegarBio(u)}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
