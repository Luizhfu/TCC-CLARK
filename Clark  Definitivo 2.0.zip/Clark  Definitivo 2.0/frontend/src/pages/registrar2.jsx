import Cabecalho_inicio from "../components/cabecalho-logar";
import React, { useState } from "react";
import axios from "axios";
import "../style/registrar.scss";

export default function Registrar2() {
  const [nome, setNome] = useState("");
  const [telefone, setTelefone] = useState("");
  const [cpf, setCpf] = useState("");
  const [endereco, setEndereco] = useState("");
  const [cep, setCep] = useState("");
  const [complemento, setComplemento] = useState("");
  const [numero, setNumero] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const handleSubmit = async (event) => {
    event.preventDefault();

    const formData = {
      nome_trab: nome,
      telefone_trab: telefone,
      cpf_trab: cpf,
      endereco_trab: endereco,
      numero_trab: numero,
      cep_trab: cep,
      complementos_trab: complemento,
      email_trab: email,
      senha_trab: senha,
    };

    try {
      const response = await axios.post(
        "http://localhost:5010/form/trabalhador",
        formData
      );
      console.log("Resposta da API:", response.data);
      alert("Trabalhador cadastrado com sucesso!");

      setNome("");
      setTelefone("");
      setCpf("");
      setEndereco("");
      setCep("");
      setComplemento("");
      setNumero("");
      setEmail("");
      setSenha("");

      const loginResponse = await axios.post("http://localhost:5010/login", {
        email: email,
        senha: senha,
      });

      const token = loginResponse.data.token;
      localStorage.setItem("token", token);

      alert("Login realizado com sucesso! Redirecionando para o chat...");
      window.location.href = "/entrar";
    } catch (error) {
      console.error("Erro ao enviar dados:", error);
      alert("Erro ao cadastrar trabalhador.");

      if (error.response && error.response.status === 401) {
        alert(
          "Usuário criado, mas o login automático falhou. Faça login manualmente."
        );
      }
    }
  };

  return (
    <div>
      <Cabecalho_inicio />
      <div className="registrar-page">
        <div className="registrar-container">
          <img
            src="src/assets/images/trabalhador_form.jpg"
            alt="imgTrabalhador"
            className="empresa-img"
          />
          <h1>TRABALHADOR</h1>

          <form className="form-empresa" onSubmit={handleSubmit}>
            <label>Nome</label>
            <input
              type="text"
              placeholder="Digite o nome do trabalhador"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
            />

            <label>Tel.</label>
            <input
              type="tel"
              placeholder="(00) 00000-0000"
              value={telefone}
              onChange={(e) => setTelefone(e.target.value)}
            />

            <label>CPF</label>
            <input
              type="text"
              placeholder="000.000.000-00"
              value={cpf}
              onChange={(e) => setCpf(e.target.value)}
            />

            <label>Endereço</label>
            <input
              type="text"
              placeholder="Rua, avenida..."
              value={endereco}
              onChange={(e) => setEndereco(e.target.value)}
            />

            <label>CEP</label>
            <input
              type="text"
              placeholder="00000-000"
              value={cep}
              onChange={(e) => setCep(e.target.value)}
            />

            <label>Complementos</label>
            <input
              type="text"
              placeholder="Apartamento, bloco..."
              value={complemento}
              onChange={(e) => setComplemento(e.target.value)}
            />

            <label>Número</label>
            <input
              type="number"
              placeholder="Ex: 123"
              value={numero}
              onChange={(e) => setNumero(e.target.value)}
            />

            <label>E-mail</label>
            <input
              type="email"
              placeholder="trabalhador@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />

            <label>Senha</label>
            <input
              type="password"
              placeholder="Digite sua senha"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
            />

            <button type="submit">Criar</button>
          </form>
        </div>
      </div>
    </div>
  );
}
