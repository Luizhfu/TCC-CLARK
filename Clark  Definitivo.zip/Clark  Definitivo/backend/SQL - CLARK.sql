create database bdclark;
use bdclark;

create table perfil_empresa (
    id int primary key auto_increment,
    nome_emp varchar(255),
    telefone_emp varchar(20),
    cnpj_emp varchar(20),
    endereco_emp varchar(255),
    numero_emp varchar(10),
    cep_emp varchar(10),
    complementos varchar(255),
    email_emp varchar(255) unique
);

create table perfil_intermediario (
    id int primary key auto_increment,
    nome_inter varchar(255),
    telefone_inter varchar(20),
    cpf_inter varchar(20),
    endereco_inter varchar(255),
    numero_inter varchar(10),
    cep_inter varchar(10),
    complementos_inter varchar(255),
    email_inter varchar(255) unique
);

create table perfil_trabalhador (
    id int primary key auto_increment,
    nome_trab varchar(255),
    telefone_trab varchar(20),
    cpf_trab varchar(20),
    endereco_trab varchar(255),
    numero_trab varchar(10),
    cep_trab varchar(10),
    complementos_trab varchar(255),
    email_trab varchar(255) unique
);

create table users (
    id_user int primary key auto_increment,
    tipo_perfil enum('empresa', 'intermediario', 'trabalhador', 'adm') not null,
    nome varchar(255) not null,
    email varchar(255) not null unique,
    senha varchar(255) not null,
    id_empresa int,
    id_intermediario int,
    id_trabalhador int,
    foreign key (id_empresa) references perfil_empresa(id),
    foreign key (id_intermediario) references perfil_intermediario(id),
    foreign key (id_trabalhador) references perfil_trabalhador(id),
    ativo boolean default 1,
    criado_em datetime default current_timestamp
);

create table recuperacao_senha (
    id int primary key auto_increment,
    usuario_id int not null,
    token varchar(255) not null,
    criado_em datetime default current_timestamp,
    expiracao datetime not null,
    usado boolean default false,
    foreign key (usuario_id) references users(id_user)
);

create table salas (
    id int primary key auto_increment,
    nome_sala varchar(255),
    usuario1_id int,
    usuario2_id int,
    criado_em timestamp default current_timestamp,
    foreign key (usuario1_id) references users(id_user),
    foreign key (usuario2_id) references users(id_user)
);

create table chat (
    id int primary key auto_increment,
    usuario_id int,
    sala_id int,
    mensagem text not null,
    criacao datetime default current_timestamp,
    foreign key (usuario_id) references users(id_user),
    foreign key (sala_id) references salas(id)
);

create table alterar_perfil (
    id_perfil int primary key auto_increment,
    nome varchar(32),
    bio varchar(3600),
    exp varchar(3600),
    projetos varchar(3600),
    img_perfil varchar(400),
    foreign key (id_perfil) references users(id_user)
);

select * from salas;
select * from chat;
select * from users;