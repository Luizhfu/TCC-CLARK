import { Router } from "express";
import { getAuthentication } from "../utils/jwt.js";
import * as repo from "../repository/empresaRepository.js";
import multer from "multer";
import bcrypt from "bcrypt";

const upload = multer({ dest: "public/storage" });
const endpoints = Router();
const autenticador = getAuthentication();

// Criar empres
endpoints.post("/form/empresa", async (req, resp) => {
  try {
    let novaEmpre = req.body;

    let idEmpresa = await repo.inserirEmpresa(novaEmpre);

    const senhaCriptografada = await bcrypt.hash(novaEmpre.senha_emp, 10);

    await repo.criarUsuarioEmpresa(
      idEmpresa,
      novaEmpre.nome_emp,
      novaEmpre.email_emp,
      senhaCriptografada
    );

    resp.send({ novoID_empresa: idEmpresa });
  } catch (error) {
    console.error("Erro ao inserir empresa e usuário:", error);
    resp.status(500).send({ erro: "Erro ao cadastrar empresa e usuário." });
  }
});

// Atualizar perfil
endpoints.put("/form-empresa/atualizar/:id", async (req, resp) => {
  try {
    let id = Number(req.params.id);
    let novosDados = req.body;

    await repo.atualizarPerfil(novosDados, id);
    resp.send({ mensagem: "Perfil atualizado com sucesso." });
  } catch (error) {
    console.error("Erro ao atualizar perfil:", error);
    resp.status(500).send({ erro: "Erro ao atualizar perfil." });
  }
});

// Alterar imagem de perfil
endpoints.put("/perfil/:id/imagem", upload.single("img"), async (req, resp) => {
  try {
    let caminho = req.file.path;
    let id = req.params.id;

    await repo.alterarImagem(id, caminho);
    resp.send({ mensagem: "Imagem atualizada com sucesso." });
  } catch (error) {
    console.error("Erro ao alterar imagem:", error);
    resp.status(500).send({ erro: "Erro ao alterar imagem." });
  }
});

export default endpoints;
