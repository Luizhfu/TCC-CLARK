import { Router } from "express";
import { getAuthentication } from "../utils/jwt.js";
import * as repo from "../repository/salaRepository.js";

const endpoints = Router();
const autenticador = getAuthentication();

//  Cria uma sala
endpoints.post("/sala", autenticador, async (req, resp) => {
  try {
    const usuario1Id = req.user.id_user;
    const { outroUsuarioId, nomeSala } = req.body;

    if (!outroUsuarioId)
      return resp.status(400).send({ erro: "Informe o outroUsuarioId." });

    const sala = await repo.criarSala(usuario1Id, outroUsuarioId, nomeSala);
    resp.send(sala);
  } catch (err) {
    console.error("Erro ao criar sala:", err);
    resp.status(500).send({ erro: "Erro ao criar sala." });
  }
});

// Lista salas
endpoints.get("/salas", autenticador, async (req, resp) => {
  try {
    const usuarioId = req.user.id_user;
    const salas = await repo.listarSalasDoUsuario(usuarioId);
    resp.send(salas);
  } catch (err) {
    console.error("Erro ao listar salas:", err);
    resp.status(500).send({ erro: "Erro ao listar salas." });
  }
});

export default endpoints;
