import { Router } from "express";
import { getAuthentication } from "../utils/jwt.js";

import * as repo from "../repository/trabalhadorRepository.js";
import multer from "multer";

const upload = multer({ dest: "public/storage" });

const endpoints = Router();
const autenticador = getAuthentication();

endpoints.post("/form/trabalhador", async (req, resp) => {
  try {
    const novoTrab = req.body;

    const idTrab = await repo.inserirTrabalhador(novoTrab);

    await repo.criarUsuarioTrabalhador(
      idTrab,
      novoTrab.nome_trab,
      novoTrab.email_trab,
      novoTrab.senha_trab
    );

    resp.send({ novoID: idTrab });
  } catch (error) {
    console.error("Erro ao inserir trabalhador:", error);
    resp.status(500).send({ erro: "Erro ao cadastrar trabalhador." });
  }
});

endpoints.put("/form-trabalhador/atualizar/:id", async (req, resp) => {
  try {
    const id = Number(req.params.id);
    const novosDados = req.body;

    await repo.atualizarPerfil(novosDados, id);

    resp.send({ mensagem: "Perfil atualizado com sucesso." });
  } catch (error) {
    console.error("Erro ao atualizar perfil:", error);
    resp.status(500).send({ erro: "Erro ao atualizar perfil." });
  }
});

endpoints.put("/perfil/:id/imagem", upload.single("img"), async (req, resp) => {
  let caminho = req.file.path;
  let id = req.params.id;

  await repo.alterarImagem(id, caminho);
  resp.send();
});

export default endpoints;
