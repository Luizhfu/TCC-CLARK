import { conection } from "./conection.js";

export async function inserirMensagem(usuarioId, salaId, mensagem) {
  const comando = `
    INSERT INTO chat (usuario_id, sala_id, mensagem, criacao)
    VALUES (?, ?, ?, NOW())
  `;
  const [result] = await conection.query(comando, [
    usuarioId,
    salaId,
    mensagem,
  ]);
  return result.insertId;
}

export async function listarMensagensPorSala(salaId) {
  try {
    const comando = `
      SELECT c.usuario_id, c.mensagem, c.criacao,
             u.nome,
             ap.img_perfil
      FROM chat c
      JOIN users u ON c.usuario_id = u.id_user
      LEFT JOIN alterar_perfil ap ON c.usuario_id = ap.id_perfil
      WHERE c.sala_id = ?
      ORDER BY c.criacao ASC
    `;
    const [registros] = await conection.query(comando, [salaId]);
    return registros.map((msg) => ({
      usuario_id: msg.usuario_id,
      mensagem: msg.mensagem,
      criacao: msg.criacao,
      nome: msg.nome || "Usuário removido",
      img_perfil: msg.img_perfil || null,
    }));
  } catch (err) {
    console.error("Erro no repository ao listar mensagens:", err);
    throw err;
  }
}
