import { conection } from "./conection.js";
import bcrypt from "bcrypt";

export async function inserirIntermediador(novoInter) {
  const comando = `
        INSERT INTO perfil_intermediario
        (nome_inter, telefone_inter, cpf_inter, endereco_inter, numero_inter, cep_inter, complementos_inter, email_inter)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?);
    `;

  const [registros] = await conection.query(comando, [
    novoInter.nome_inter,
    novoInter.telefone_inter,
    novoInter.cpf_inter,
    novoInter.endereco_inter,
    novoInter.numero_inter,
    novoInter.cep_inter,
    novoInter.complementos_inter,
    novoInter.email_inter,
  ]);

  return registros.insertId;
}

export async function criarUsuarioIntermediador(idInter, nome, email, senha) {
  const senhaCriptografada = await bcrypt.hash(senha, 10);

  const comando = `
        INSERT INTO users (tipo_perfil, nome, email, senha, id_intermediario)
        VALUES ('intermediario', ?, ?, ?, ?);
    `;

  const [resultado] = await conection.query(comando, [
    nome,
    email,
    senhaCriptografada,
    idInter,
  ]);

  return resultado.insertId;
}

export async function atualizarPerfil(novosDados, id) {
  const comando = `
        UPDATE alterar_perfil
        SET nome = ?, bio = ?, exp = ?, projetos = ?
        WHERE id_perfil = ?;
    `;

  const [registros] = await conection.query(comando, [
    novosDados.nome,
    novosDados.bio,
    novosDados.exp,
    novosDados.projetos,
    id,
  ]);

  return registros.affectedRows;
}

export async function alterarImagem(id, caminho) {
  const comando = `
        UPDATE alterar_perfil
        SET img_perfil = ?
        WHERE id_perfil = ?;
    `;

  const [info] = await conection.query(comando, [caminho, id]);
  return info.affectedRows;
}
