import { conection } from "./conection.js";

// 🔹 Cria uma sala entre dois usuários (ou retorna a existente)
export async function criarSala(usuario1Id, usuario2Id, nomeSala) {
  // Verifica se já existe sala entre os dois usuários
  const verificar = `
    SELECT * FROM salas 
    WHERE (usuario1_id = ? AND usuario2_id = ?)
       OR (usuario1_id = ? AND usuario2_id = ?)
  `;
  const [existe] = await conection.query(verificar, [
    usuario1Id,
    usuario2Id,
    usuario2Id,
    usuario1Id,
  ]);

  if (existe.length > 0) {
    return existe[0]; // sala já existente
  }

  // Cria nova sala
  const comando = `
    INSERT INTO salas (nome_sala, usuario1_id, usuario2_id)
    VALUES (?, ?, ?)
  `;
  const [result] = await conection.query(comando, [
    nomeSala,
    usuario1Id,
    usuario2Id,
  ]);

  return {
    id: result.insertId,
    nome_sala: nomeSala,
    usuario1_id: usuario1Id,
    usuario2_id: usuario2Id,
  };
}

// 🔹 Lista todas as salas em que o usuário participa
export async function listarSalasDoUsuario(usuarioId) {
  const comando = `
    SELECT 
      s.id AS id,
      s.nome_sala AS nome,
      u1.nome AS usuario1_nome,
      u2.nome AS usuario2_nome
    FROM salas s
    JOIN users u1 ON s.usuario1_id = u1.id_user
    JOIN users u2 ON s.usuario2_id = u2.id_user
    WHERE s.usuario1_id = ? OR s.usuario2_id = ?
  `;
  const [salas] = await conection.query(comando, [usuarioId, usuarioId]);
  return salas;
}
