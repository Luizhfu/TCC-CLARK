import { conection } from "./conection.js";
import bcrypt from "bcrypt";

export async function criarConta(novoLogin) {
  const hash = await bcrypt.hash(novoLogin.senha, 10);

  const tipoPerfil = novoLogin.tipo_perfil || "user";

  const comando = `
    insert into users (nome, email, senha, tipo_perfil)
    values (?, ?, ?, ?)
  `;

  const [info] = await conection.query(comando, [
    novoLogin.nome,
    novoLogin.email,
    hash,
    tipoPerfil,
  ]);

  return info.insertId;
}

export async function validarCredenciais(email, senha) {
  const comando = `
    select id_user, nome, email, tipo_perfil, senha from users
    where email = ?
  `;

  const [registros] = await conection.query(comando, [email]);
  const usuario = registros[0];

  if (!usuario) return null;

  const senhaValida = await bcrypt.compare(senha, usuario.senha);
  if (!senhaValida) return null;

  delete usuario.senha;
  return usuario;
}

export async function buscarPorEmail(email) {
  const comando = `
  select id_user, nome, email, tipo_perfil from users
  where email = ?
  `;

  const [registros] = await conection.query(comando, [email]);
  return registros[0] || null;
}

export async function atualizarSenha(id_user, novaSenha) {
  const hash = await bcrypt.hash(novaSenha, 10);

  const comando = `
  update users 
  set senha = ? 
  where id_user = ?
  `;

  await conection.query(comando, [hash, id_user]);
}

export async function deletarUsuario(id) {
  const comando = `delete from users 
  where id_user = ?`;

  await conection.query(comando, [id]);
}

export async function buscarPorId(id) {
  const comando = `
    select id_user, nome, email, tipo_perfil from users
    where id_user = ?
  `;

  const [registros] = await conection.query(comando, [id]);
  return registros[0] || null;
}

export async function buscarPerfilCompleto(id) {
  const comando = `
    select u.id_user, u.nome, u.email, u.tipo_perfil, p.bio, p.exp, p.projetos, p.img_perfil from users u
    left join alterar_perfil p ON u.id_user = p.id_perfil
    where u.id_user = ?
  `;

  const [registros] = await conection.query(comando, [id]);
  return registros[0] || null;
}

export async function atualizarPerfil(novosDados, id) {
  const comandoVerificar = `select * from alterar_perfil 
  where id_perfil = ?`;

  const [existe] = await conection.query(comandoVerificar, [id]);

  let comando;
  let parametros;

  if (existe.length > 0) {
    comando = `
      update alterar_perfil 
      set nome = ?, bio = ?, exp = ?, projetos = ?
      where id_perfil = ?
    `;
    parametros = [
      novosDados.nome,
      novosDados.bio,
      novosDados.exp,
      novosDados.projetos,
      id,
    ];
  } else {
    comando = `
     insert into alterar_perfil (id_perfil, nome, bio, exp, projetos)
      values (?, ?, ?, ?, ?)
    `;
    parametros = [
      id,
      novosDados.nome,
      novosDados.bio,
      novosDados.exp,
      novosDados.projetos,
    ];
  }

  await conection.query(comando, parametros);

  const comandoUsers = `update users 
  set nome = ? 
  where id_user = ?`;

  await conection.query(comandoUsers, [novosDados.nome, id]);
}

export async function atualizarImagemPerfil(id, caminho) {
  const comandoVerificar = `select * from alterar_perfil 
  where id_perfil = ?`;

  const [existe] = await conection.query(comandoVerificar, [id]);

  let comando;
  let parametros;

  if (existe.length > 0) {
    comando = `update alterar_perfil 
    set img_perfil = ? 
    where id_perfil = ?`;

    parametros = [caminho, id];
  } else {
    comando = `insert into alterar_perfil (id_perfil, img_perfil) 
    values (?, ?)`;

    parametros = [id, caminho];
  }

  await conection.query(comando, parametros);
}
