import { getTokenInfoFromToken } from '../utils/jwt.js';

export function autenticarIntermediador(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader)
      return res.status(401).json({ erro: 'Token não fornecido' });

    const token = authHeader.split(' ')[1];
    if (!token)
      return res.status(401).json({ erro: 'Token inválido' });

    
    const payload = getTokenInfoFromToken(token);

    if (!payload)
      return res.status(401).json({ erro: 'Token inválido ou expirado' });

    if (payload.tipo_perfil !== 'intermediario') {
      return res.status(403).json({ erro: 'Acesso negado' });
    }

    req.usuario = payload;
    next();
  } catch (err) {
    console.error(err);
    res.status(401).json({ erro: 'Token inválido' });
  }
}
