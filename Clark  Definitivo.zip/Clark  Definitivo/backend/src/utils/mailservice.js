import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com', 
    port: 465, 
    secure: true, 
    auth: {
        user: 'contato.clark06@exemplo.com',
        pass: 'fktq pqei eumt ieog'   
    }
});


export async function sendMail(to, subject, text) {
    const mailOptions = {
        from: '"Seu App" <contato.clark06@exemplo.com>', 
        to,       
        subject, 
        text      
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('Email enviado: %s', info.messageId);
    return info;
}

