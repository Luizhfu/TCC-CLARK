import "../components/cabecalho.scss";
import Clark from "../assets/images/Clark_2.0-semFundo.png";
import { Link } from "react-router";

export default function Cabecalho() {
  return (
    <div className="cabecalho-geral">
      <section className="Barra-top">
        <div className="lg">
          <img className="logo2" src={Clark} alt="" />
        </div>

        <nav className="links">
          <h3>
            <Link to="/">Inicio</Link>
          </h3>

          <h3>
            <Link to="/entrar">Entrar</Link>
          </h3>

          <h3>
            <Link to="/escolha">Resgistrar</Link>
          </h3>
        </nav>
      </section>
    </div>
  );
}
