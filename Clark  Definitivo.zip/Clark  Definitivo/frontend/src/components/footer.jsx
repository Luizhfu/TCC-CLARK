import "../components/footer.scss";
import Frei from "../assets/images/Logo-Frei.png";

export default function Footer() {
  return (
    <div className="footer">
      <section className="Barra-bottom">
        <div className="participantes">
          <h3>-Participantes-</h3>

          <div className="nomes">
            <div>
              <ul>
                <li>Júlio César</li>
                <li>Luca Bernardes</li>
                <li>Nicolas Pereira</li>
              </ul>
            </div>

            <div>
              <ul>
                <li>Pedro H. Lopes</li>
                <li>Victor Gabriel</li>
                <li>Luiz Eduardo</li>
              </ul>
            </div>
          </div>

          <h4>Informatica C - Tarde - 2025</h4>
        </div>

        <div className="frei">
          <div className="div-img-frei">
            <img src={Frei} alt="Logo Frei" />
          </div>

          <div className="div-h2-frei">
            <h2 className="h2-frei-1">Instituto de Nossa</h2>

            <h2 className="h2-frei-2">Senhora de Fátima</h2>
          </div>
        </div>
      </section>
    </div>
  );
}
