import { useEffect, useState } from "react";
import axios from "axios";
import "../style/adm.scss";
import { useNavigate } from "react-router";

export default function ADM() {
  const [usuarios, setUsuarios] = useState([]);
  const [erro, setErro] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUsuarios = async () => {
      try {
        const token = localStorage.getItem("token");

        if (!token) {
          setErro("Acesso negado. Você precisa estar logado como ADM.");
          navigate("/entrar");
          return;
        }

        const payload = JSON.parse(atob(token.split(".")[1]));

        if (payload.tipo_perfil !== "adm") {
          setErro(
            "Acesso negado. Apenas administradores podem acessar esta página."
          );
          navigate("/entrar");
          return;
        }

        const response = await axios.get("http://localhost:5010/adm", {
          headers: { Authorization: `Bearer ${token}` },
        });

        setUsuarios(response.data);
      } catch (err) {
        console.error("Erro ao buscar usuários:", err);
        setErro("Erro ao buscar usuários ou acesso negado.");
      }
    };

    fetchUsuarios();
  }, [navigate]);

  if (erro) {
    return <div className="erro">{erro}</div>;
  }

  return (
    <div className="main">
      <div className="cabecalho">
        <h1 className="titulo">DADOS ATUAIS:</h1>
      </div>

      <div className="conteiner-tabela">
        <table className="tabela-usuarios">
          <thead>
            <tr>
              <th>Usuários Ativos</th>
              <th>Tipo de Perfil</th>
              <th>Email</th>
              <th>Criado em</th>
            </tr>
          </thead>
          <tbody>
            {usuarios.map((u, index) => (
              <tr key={index}>
                <td>{u.ativo ? "Ativo" : "Inativo"}</td>
                <td>{u.tipo_perfil}</td>
                <td>{u.email}</td>
                <td>{u.criado_em}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
