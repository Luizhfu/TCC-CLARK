import axios from "axios";
import React, { useState, useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import Cabecalho from "../components/cabecalho-perfilPadrao-chat";
import "../style/chat.scss";
import jwt_decode from "jwt-decode";

export default function Chat() {
  const [salas, setSalas] = useState([]);
  const [salaSelecionada, setSalaSelecionada] = useState(null);
  const [messages, setMessages] = useState([]);
  const [message, setMessage] = useState("");
  const [USER_ID, setUserId] = useState(null);

  const API_URL = "http://localhost:5010";
  const TOKEN = localStorage.getItem("token");
  const messageContainerRef = useRef(null);

  const query = new URLSearchParams(useLocation().search);
  const salaIdParam = query.get("salaId");

  useEffect(() => {
    if (TOKEN) {
      try {
        const decoded = jwt_decode(TOKEN);
        setUserId(decoded.id_user);
      } catch (err) {
        console.error("Token inválido:", err);
      }
    }
  }, [TOKEN]);

  useEffect(() => {
    if (salaIdParam) setSalaSelecionada(Number(salaIdParam));
  }, [salaIdParam]);

  useEffect(() => {
    if (!TOKEN) return;
    const headers = { "x-access-token": TOKEN };

    async function fetchSalas() {
      try {
        const resp = await axios.get(`${API_URL}/salas`, { headers });
        setSalas(resp.data);
      } catch (err) {
        console.error("Erro ao carregar salas:", err);
      }
    }

    fetchSalas();
  }, [TOKEN]);

  useEffect(() => {
    if (!salaSelecionada || !USER_ID || !TOKEN) return;
    const headers = { "x-access-token": TOKEN };

    async function fetchMessages() {
      try {
        const resp = await axios.get(`${API_URL}/chat/${salaSelecionada}`, {
          headers,
        });
        setMessages(resp.data);
        scrollToBottomIfNearEnd();
      } catch (err) {
        if (err.response?.status === 403) {
          console.warn("Você não tem acesso a essa sala.");
        } else {
          console.error("Erro ao carregar mensagens:", err);
        }
      }
    }

    fetchMessages();
    const interval = setInterval(fetchMessages, 1500);
    return () => clearInterval(interval);
  }, [salaSelecionada, USER_ID, TOKEN]);

  async function handleSendMessage() {
    if (!message.trim() || !salaSelecionada || !USER_ID || !TOKEN) return;
    const headers = { "x-access-token": TOKEN };

    try {
      await axios.post(
        `${API_URL}/chat/${salaSelecionada}`,
        { usuarioId: USER_ID, mensagem: message },
        { headers }
      );
      setMessage("");
    } catch (err) {
      if (err.response?.status === 403) {
        alert("Você não tem permissão para enviar mensagens nesta sala.");
      } else {
        console.error("Erro ao enviar mensagem:", err);
      }
    }
  }

  const scrollToBottomIfNearEnd = () => {
    const container = messageContainerRef.current;
    if (!container) return;
    const isNearBottom =
      container.scrollHeight - container.scrollTop - container.clientHeight <
      50;
    if (isNearBottom) container.scrollTop = container.scrollHeight;
  };

  return (
    <div className="main-chat">
      <Cabecalho />

      <div className="chat-layout">
        <div className="sidebar">
          <h3>Conversas</h3>
          <ul className="salas-lista">
            {salas.map((sala) => (
              <li
                key={sala.id}
                className={`sala-item ${
                  salaSelecionada === sala.id ? "ativa" : ""
                }`}
                onClick={() => setSalaSelecionada(sala.id)}
              >
                {sala.nome || `Sala ${sala.id}`}
              </li>
            ))}
          </ul>
        </div>

        <div className="chat-caixa">
          {salaSelecionada ? (
            <>
              <div className="message-container" ref={messageContainerRef}>
                {messages.length > 0 ? (
                  messages.map((msg, index) => (
                    <div
                      key={index}
                      className={`message ${
                        msg.usuario_id === USER_ID ? "sent" : "received"
                      }`}
                    >
                      {msg.img_perfil ? (
                        <img
                          src={
                            msg.img_perfil.startsWith("http")
                              ? msg.img_perfil
                              : `${API_URL}/${msg.img_perfil}`
                          }
                          alt="avatar"
                          className="avatar"
                        />
                      ) : (
                        <div className="avatar">👤</div>
                      )}

                      <div className="msg-content">
                        <div className="msg-info">
                          {msg.nome || "Usuário removido"}
                        </div>
                        <div className="msg-text">{msg.mensagem}</div>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="sem-mensagens">Nenhuma mensagem ainda...</p>
                )}
              </div>

              <div className="input-container">
                <input
                  className="input-chat"
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Digite sua mensagem..."
                  onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                />
                <button className="btn-chat" onClick={handleSendMessage}>
                  Enviar
                </button>
              </div>
            </>
          ) : (
            <p className="selecione-aviso">
              Selecione uma conversa à esquerda 👈
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
