import Cabecalho_inicio from "../components/cabecalho-inicio";
import Footer from "../components/footer";
import "../style/inicio.scss";
import { Link } from "react-router";

export default function Inicio() {
  return (
    <div className="Clark">
      <Cabecalho_inicio></Cabecalho_inicio>

      <div className="Bem-vindo">
        <h1 className="inria-serif-bold-italic">Bem Vindo ao Clark</h1>
        <img
          className="Imagem-Entrada"
          height="300px"
          src="src/assets/images/Clark_2.0.png"
          alt=""
        />

        <div className="circleYellow"></div>
        <div className="circulo YP p1"></div>
        <div className="triangulo YP p2"></div>
        <div className="hexagono YP p3"></div>
        <div className="circulo YP p4"></div>
        <div className="triangulo YP p5"></div>

        <div className="div-btn">
          <button className="inria-serif-regular btn">
            <Link to={"./entrar"}>ENTRAR</Link>
          </button>

          <button className="inria-serif-regular btn">
            <Link to={"./escolha"}>CADASTRAR</Link>
          </button>
        </div>
      </div>

      <section className="secao">
        <div className="bloco-direita">
          <div className="textos">
            <h1>Empresa</h1>
            <p>
              É uma organização que produz bens ou oferece serviços com o
              objetivo de obter lucro. Ela pode atuar em diferentes áreas, como
              comércio, indústria ou prestação de serviços.
            </p>
          </div>

          <div className="div-img-D">
            <img src="/src/assets/images/Selo Empresa.png" alt="" />
          </div>
        </div>
      </section>

      <section className="secao">
        <div className="bloco-esquerda">
          <div className="textos">
            <h1>Intermediador</h1>
            <p>
              Um intermediador serve para fazer a ponte entre duas partes,
              facilitando a comunicação, negociação ou troca de informações
              entre elas. Ele atua como um meio de ligação, garantindo que os
              dados ou acordos sejam transmitidos corretamente e de forma segura
            </p>
          </div>

          <div className="div-img-E">
            <img src="/src/assets/images/Selo Mediador.png" alt="" />
          </div>
        </div>
      </section>

      <section className="secao">
        <div className="bloco-direita">
          <div className="textos">
            <h1>Trabalhador</h1>
            <p>
              Um trabalhador é a pessoa que realiza atividades ou presta
              serviços em uma empresa, com o objetivo de produzir bens, atender
              clientes ou contribuir para o funcionamento do negócio. Ele pode
              atuar em diferentes funções, de acordo com sua formação e
              habilidades, e recebe uma remuneração pelo seu trabalho.
            </p>
          </div>

          <div className="div-img-D">
            <img src="/src/assets/images/Selo Empregado.png" alt="" />
          </div>
        </div>
      </section>

      <Footer></Footer>
    </div>
  );
}
