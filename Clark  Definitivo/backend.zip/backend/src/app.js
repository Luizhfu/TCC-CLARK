import { adicionarRotas } from "./rotas.js";
import express from "express";
import cors from "cors";
import logarEndpoints from "./controller/logarController.js";
import path from "path";
import { fileURLToPath } from "url";

const api = express();
api.use(express.json());
api.use(cors());

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

api.use("/storage", express.static(path.join(__dirname, "public/storage")));

adicionarRotas(api);

api.use("/", logarEndpoints);
api.listen(5010, () => console.log("✅ Servidor rodando na porta 5010"));
