import { Router } from "express";
import * as repo from "../repository/admRepository.js";
import { autenticarAdm } from "../utils/admMiddleware.js";

const endpoints = Router();

endpoints.get("/adm", autenticarAdm, async (req, resp) => {
  try {
    const usuarios = await repo.listarUsuarios();
    resp.send(usuarios);
  } catch (err) {
    console.error("Erro ao buscar usuários:", err);
    resp.status(500).send({ erro: "Erro ao buscar usuários" });
  }
});

export default endpoints;
