import { Router } from "express";
import { loginUser } from "../repository/logarRepository.js";
import { generateToken } from "../utils/jwt.js";

const router = Router();

// POST /login
router.post("/login", async (req, res) => {
  const { email, senha } = req.body;

  try {
    const user = await loginUser(email, senha);

    if (!user) {
      return res.status(401).send({ erro: "Email ou senha incorretos!" });
    }

    const token = generateToken(user); // gera JWT

    // Retornar token + dados do usuário
    res.send({ token, user });
  } catch (err) {
    console.error(err);
    res.status(500).send({ erro: "Erro interno do servidor" });
  }
});

export default router;
