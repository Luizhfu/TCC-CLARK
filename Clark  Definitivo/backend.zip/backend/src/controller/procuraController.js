import { Router } from "express";
import * as repo from "../repository/procuraRepository.js";

const endpoints = Router();

// Buscar empresas ou trabalhadores
endpoints.get("/procura/:tipo", async (req, resp) => {
  const tipo = req.params.tipo;

  try {
    let lista;
    if (tipo === "empresa") {
      lista = await repo.listarEmpresas();
    } else if (tipo === "funcionario") {
      lista = await repo.listarTrabalhadores();
    } else {
      return resp.status(400).send({ erro: "Tipo inválido" });
    }

    lista = lista.map((u) => {
      if (u.img_perfil) {
        u.img_perfil = u.img_perfil.replace(/\\/g, "/");
      }
      return u;
    });

    resp.send(lista);
  } catch (erro) {
    console.error("Erro ao buscar usuários:", erro);
    resp.status(500).send({ erro: "Erro ao buscar usuários" });
  }
});

export default endpoints;
