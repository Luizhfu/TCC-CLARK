import { conection } from "./conection.js";

export async function listarUsuarios() {
  const comando = `
        SELECT email, tipo_perfil, ativo, date_format(criado_em, '%d/%m/%Y %H:%i:%s') as criado_em
        FROM users;
    `;
  const [usuarios] = await conection.query(comando);
  return usuarios;
}
