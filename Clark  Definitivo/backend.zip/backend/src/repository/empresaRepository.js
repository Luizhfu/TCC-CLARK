import { conection } from "./conection.js";

export async function inserirEmpresa(novaEmpre) {
  const comando = `
    INSERT INTO perfil_empresa 
    (nome_emp, telefone_emp, cnpj_emp, endereco_emp, numero_emp, cep_emp, complementos, email_emp)
    VALUES (?,?,?,?,?,?,?,?);`;

  const [registros] = await conection.query(comando, [
    novaEmpre.nome_emp,
    novaEmpre.telefone_emp,
    novaEmpre.cnpj_emp,
    novaEmpre.endereco_emp,
    novaEmpre.numero_emp,
    novaEmpre.cep_emp,
    novaEmpre.complementos,
    novaEmpre.email_emp,
  ]);

  return registros.insertId;
}

export async function atualizarPerfil(novosDados, id) {
  const comando = `
    UPDATE alterar_perfil
       SET nome = ?, bio = ?, exp = ?, projetos = ?
     WHERE id_perfil = ?;`;

  const [registros] = await conection.query(comando, [
    novosDados.nome,
    novosDados.bio,
    novosDados.exp,
    novosDados.projetos,
    id,
  ]);

  return registros.affectedRows;
}

export async function alterarImagem(id, caminho) {
  const comando = `
      UPDATE alterar_perfil
         SET img_perfil = ?
       WHERE id_perfil = ?;`;

  const [info] = await conection.query(comando, [caminho, id]);
  return info.affectedRows;
}

export async function criarUsuarioEmpresa(idEmpresa, nome, email, senha) {
  const comando = `
      INSERT INTO users (tipo_perfil, nome, email, senha, id_empresa)
      VALUES ('empresa', ?, ?, ?, ?);`;

  const [resultado] = await conection.query(comando, [
    nome,
    email,
    senha,
    idEmpresa,
  ]);
  return resultado.insertId;
}
