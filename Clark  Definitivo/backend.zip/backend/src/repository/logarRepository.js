import { conection } from "./conection.js";
import bcrypt from "bcryptjs";

export async function loginUser(email, senhaDigitada) {
  const [rows] = await conection.query(
    "SELECT id_user, nome, tipo_perfil, senha FROM users WHERE email = ?",
    [email]
  );

  if (rows.length === 0) return null;

  const user = rows[0];

  const senhaValida = await bcrypt.compare(senhaDigitada, user.senha);
  if (!senhaValida) return null;

  return {
    id_user: user.id_user,
    nome: user.nome,
    tipo_perfil: user.tipo_perfil,
  };
}
