import { conection } from "./conection.js";

export async function listarEmpresas() {
  const comando = `
    SELECT e.id AS id,
           e.nome_emp AS nome,
           e.telefone_emp AS telefone,
           e.email_emp AS email,
           a.img_perfil,
           a.bio
    FROM perfil_empresa e
    LEFT JOIN users u ON u.id_empresa = e.id
    LEFT JOIN alterar_perfil a ON a.id_perfil = u.id_user
  `;
  const [registros] = await conection.query(comando);
  return registros;
}

export async function listarTrabalhadores() {
  const comando = `
    SELECT t.id AS id,
           t.nome_trab AS nome,
           t.telefone_trab AS telefone,
           t.email_trab AS email,
           a.img_perfil,
           a.bio
    FROM perfil_trabalhador t
    LEFT JOIN users u ON u.id_trabalhador = t.id
    LEFT JOIN alterar_perfil a ON a.id_perfil = u.id_user
  `;
  const [registros] = await conection.query(comando);
  return registros;
}
