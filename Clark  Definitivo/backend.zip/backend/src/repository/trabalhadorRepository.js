import { conection } from "./conection.js";
import bcrypt from "bcrypt";

export async function inserirTrabalhador(novoTrabalhador) {
  const comando = `
    INSERT INTO perfil_trabalhador
      (nome_trab,
       telefone_trab,
       cpf_trab,
       endereco_trab,
       numero_trab,
       cep_trab,
       complementos_trab,
       email_trab)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?);
  `;

  const [registros] = await conection.query(comando, [
    novoTrabalhador.nome_trab,
    novoTrabalhador.telefone_trab,
    novoTrabalhador.cnpj_trab,
    novoTrabalhador.endereco_trab,
    novoTrabalhador.numero_trab,
    novoTrabalhador.cep_trab,
    novoTrabalhador.complementos,
    novoTrabalhador.email_trab,
  ]);

  return registros.insertId;
}

export async function criarUsuarioTrabalhador(idTrab, nome, email, senha) {
  const senhaCriptografada = await bcrypt.hash(senha, 10);

  const comando = `
        INSERT INTO users (tipo_perfil, nome, email, senha, id_trabalhador)
        VALUES ('trabalhador', ?, ?, ?, ?);
    `;

  const [resultado] = await conection.query(comando, [
    nome,
    email,
    senhaCriptografada,
    idTrab,
  ]);

  return resultado.insertId;
}

export async function atualizarPerfil(novosDados, id) {
  const comando = `
    update alterar_perfil
      set nome = ?,
      bio = ?,
      exp = ? ,
      projetos= ?,
   where id_perfil = ?;`;

  const [registros] = await conection.query(comando, [
    novosDados.nome,
    novosDados.bio,
    novosDados.exp,
    novosDados.projetos,
    id,
  ]);
}

export async function alterarImagem(id, caminho) {
  const comando = `
      update alterar_perfil
        set img_perfil = ?
       where id_perfil = ?`;

  const [info] = await conection.query(comando, [caminho, id]);
}
