import express from 'express';

import chatController from './controller/chatController.js';
import salaController from './controller/salaController.js';

import usuarioController from './controller/usuarioController.js';
import autenticacaoController from './controller/autenticacaoController.js';

import empresaController from './controller/empresaController.js';
import intermediarController from './controller/intermediarController.js';

import trabalhadorController from './controller/trabalhadorController.js';
import admController from './controller/admController.js';

import logarController from './controller/logarController.js'

import procuraController from './controller/procuraController.js';

export function adicionarRotas(api) {
  api.use(chatController);
  api.use(salaController);
  api.use(usuarioController);
  api.use(autenticacaoController);
  api.use(empresaController);
  api.use(intermediarController);
  api.use(trabalhadorController);
  api.use(admController);
  api.use(logarController);
  api.use(procuraController);

  api.use('/public/storage', express.static('public/storage'));
}


