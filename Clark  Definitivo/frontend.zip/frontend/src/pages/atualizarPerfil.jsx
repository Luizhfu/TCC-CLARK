import React, { useState, useEffect } from "react";
import axios from "axios";
import "../style/atualizarPerfil.scss";
import Cabecalho from "../components/cabecalho-perfilPadrao-perfil";

export default function Perfil() {
  const [nome, setNome] = useState("");
  const [bio, setBio] = useState("");
  const [exp, setExp] = useState("");
  const [projetos, setProjetos] = useState("");
  const [imgPerfil, setImgPerfil] = useState("");
  const [userId, setUserId] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    buscarDadosUsuario();
  }, []);

  const buscarDadosUsuario = () => {
    const userData = localStorage.getItem("userData");
    const token = localStorage.getItem("token");

    if (userData && token) {
      const user = JSON.parse(userData);
      setUserId(user.id_user);
      buscarPerfil(user.id_user);
    } else {
      console.log("Usuário não encontrado no localStorage");
      alert("Faça login novamente");
    }
  };

  const buscarPerfil = async (id) => {
    try {
      setLoading(true);
      const token = localStorage.getItem("token");

      const response = await axios.get(
        `http://localhost:5010/usuario/perfil-completo/${id}`,
        {
          headers: {
            "x-access-token": token,
          },
        }
      );

      const dados = response.data;
      setNome(dados.nome || "");
      setBio(dados.bio || "");
      setExp(dados.exp || "");
      setProjetos(dados.projetos || "");

      if (dados.img_perfil) {
        setImgPerfil(
          dados.img_perfil.startsWith("http")
            ? dados.img_perfil
            : `http://localhost:5010/${dados.img_perfil}`
        );
      }
    } catch (error) {
      console.error("Erro ao buscar perfil:", error);
      if (error.response?.status === 401) {
        alert("Sessão expirada. Faça login novamente.");
      } else {
        alert("Erro ao carregar perfil.");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSalvar = async (event) => {
    event.preventDefault();

    if (!userId) {
      alert("Usuário não identificado. Faça login novamente.");
      return;
    }

    const formData = { nome, bio, exp, projetos };

    try {
      setLoading(true);
      const token = localStorage.getItem("token");

      const response = await axios.put(
        `http://localhost:5010/usuario/perfil/${userId}`,
        formData,
        {
          headers: {
            "x-access-token": token,
          },
        }
      );

      console.log("Resposta da API:", response.data);
      alert("Perfil atualizado com sucesso!");
    } catch (error) {
      console.error("Erro ao atualizar perfil:", error);
      alert("Erro ao atualizar perfil.");
    } finally {
      setLoading(false);
    }
  };

  const handleDescartar = () => {
    if (userId) buscarPerfil(userId);
    alert("Alterações descartadas");
  };

  const handleEditarFoto = async (event) => {
    const file = event.target.files[0];
    if (file && userId) {
      try {
        setLoading(true);
        const token = localStorage.getItem("token");
        const formData = new FormData();
        formData.append("img", file);

        const response = await axios.put(
          `http://localhost:5010/usuario/${userId}/imagem`,
          formData,
          {
            headers: {
              "x-access-token": token,
              "Content-Type": "multipart/form-data",
            },
          }
        );

        const caminho = response.data.caminho;
        setImgPerfil(`http://localhost:5010/${caminho}`);
        alert("Imagem atualizada com sucesso!");
      } catch (error) {
        console.error("Erro ao fazer upload da imagem:", error);
        alert("Erro ao atualizar imagem.");
      } finally {
        setLoading(false);
      }
    }
  };

  const triggerFileInput = () => {
    const fileInput = document.createElement("input");
    fileInput.type = "file";
    fileInput.accept = "image/*";
    fileInput.onchange = handleEditarFoto;
    fileInput.click();
  };

  if (loading) {
    return <div className="container-perfil">Carregando...</div>;
  }

  return (
    <div>
      <Cabecalho />
      <div className="container-perfil">
        <div className="foto-perfil">
          {imgPerfil ? (
            <img src={imgPerfil} alt="foto de perfil" height={100} />
          ) : (
            <div className="avatar-placeholder">
              <span>👤</span>
              <small>Sem foto</small>
            </div>
          )}
        </div>

        <div className="butaum">
          <button
            className="btn-editar"
            onClick={triggerFileInput}
            type="button"
            disabled={loading}
          >
            ✏ editar
          </button>
        </div>

        <label>Nome</label>
        <input
          type="text"
          value={nome}
          onChange={(e) => setNome(e.target.value)}
          disabled={loading}
        />

        <label>Bio</label>
        <textarea
          value={bio}
          onChange={(e) => setBio(e.target.value)}
          disabled={loading}
          rows={4}
        />

        <label>Experiências e vida acadêmica</label>
        <textarea
          value={exp}
          onChange={(e) => setExp(e.target.value)}
          disabled={loading}
          rows={4}
        />

        <label>Projetos</label>
        <textarea
          value={projetos}
          onChange={(e) => setProjetos(e.target.value)}
          disabled={loading}
          rows={4}
        />

        <div className="botoes">
          <button
            className="btn-descartar"
            onClick={handleDescartar}
            disabled={loading}
          >
            Descartar
          </button>
          <button
            className="btn-salvar"
            onClick={handleSalvar}
            disabled={loading}
          >
            {loading ? "Salvando..." : "Salvar"}
          </button>
        </div>
      </div>
    </div>
  );
}
