import Cabecalho_inicio from "../components/cabecalho-logar";
import React, { useState } from "react";
import axios from "axios";
import "../style/registrar.scss";

export default function Registrar() {
  const [nome, setNome] = useState("");
  const [telefone, setTelefone] = useState("");
  const [cnpj, setCnpj] = useState("");
  const [endereco, setEndereco] = useState("");
  const [cep, setCep] = useState("");
  const [complemento, setComplemento] = useState("");
  const [numero, setNumero] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const handleSubmit = async (event) => {
    event.preventDefault();

    const formData = {
      nome_emp: nome,
      telefone_emp: telefone,
      cnpj_emp: cnpj,
      endereco_emp: endereco,
      numero_emp: numero,
      cep_emp: cep,
      complementos: complemento,
      email_emp: email,
      senha_emp: senha,
    };

    try {
      const response = await axios.post(
        "http://localhost:5010/form/empresa",
        formData
      );
      console.log("Resposta da API:", response.data);
      alert("Empresa cadastrada com sucesso!");

      setNome("");
      setTelefone("");
      setCnpj("");
      setEndereco("");
      setCep("");
      setComplemento("");
      setNumero("");
      setEmail("");
      setSenha("");

      const loginResponse = await axios.post(
        "http://localhost:5010/usuario/login",
        {
          email: email,
          senha: senha,
        }
      );

      const token = loginResponse.data.token;
      localStorage.setItem("token", token);

      alert("Login realizado com sucesso! Redirecionando para o chat...");
      window.location.href = "/entrar";
    } catch (error) {
      console.error("Erro ao enviar dados:", error);
      alert("Erro ao cadastrar empresa.");

      console.error("Erro durante o registro ou login:", error);

      if (error.response && error.response.status === 401) {
        alert(
          "Usuário criado, mas o login automático falhou. Faça login manualmente."
        );
      } else {
        alert("Erro ao cadastrar empresa.");
      }
    }
  };

  return (
    <div>
      <Cabecalho_inicio></Cabecalho_inicio>
      <div className="registrar-page">
        <div className="registrar-container">
          <img
            src="src/assets/images/empresa_form.png"
            alt="imgEmpresa"
            className="empresa-img"
          />
          <h1>EMPRESA</h1>

          <form className="form-empresa" onSubmit={handleSubmit}>
            <label>Nome</label>
            <input
              type="text"
              placeholder="Digite o nome da empresa"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
            />

            <label>Tel.</label>
            <input
              type="tel"
              placeholder="(00) 00000-0000"
              value={telefone}
              onChange={(e) => setTelefone(e.target.value)}
            />

            <label>CNPJ</label>
            <input
              type="text"
              placeholder="00.000.000/0000-00"
              value={cnpj}
              onChange={(e) => setCnpj(e.target.value)}
            />

            <label>Endereço</label>
            <input
              type="text"
              placeholder="Rua, avenida..."
              value={endereco}
              onChange={(e) => setEndereco(e.target.value)}
            />

            <label>CEP</label>
            <input
              type="text"
              placeholder="00000-000"
              value={cep}
              onChange={(e) => setCep(e.target.value)}
            />

            <label>Complementos</label>
            <input
              type="text"
              placeholder="Apartamento, bloco..."
              value={complemento}
              onChange={(e) => setComplemento(e.target.value)}
            />

            <label>Número</label>
            <input
              type="number"
              placeholder="Ex: 123"
              value={numero}
              onChange={(e) => setNumero(e.target.value)}
            />

            <label>E-mail</label>
            <input
              type="email"
              placeholder="empresa@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />

            <label>Senha</label>
            <input
              type="password"
              placeholder="Digite sua senha"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
            />

            <button type="submit">Criar</button>
          </form>
        </div>
      </div>
    </div>
  );
}
